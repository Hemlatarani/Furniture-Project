import axios from "axios";
let bannerapi=()=>{
  return  axios.get('https://dummyjson.com/products')
.then(res => res.data)
.then((finalRes)=>finalRes.products.slice(0,4));
}

let homeFeaturedProduct=(cartname='furniture')=>{
  return  axios.get(`https://dummyjson.com/products/category/${cartname}`)

.then(res => res.data)
.then((finalRes)=>finalRes.products.slice());
}

export {bannerapi, homeFeaturedProduct}