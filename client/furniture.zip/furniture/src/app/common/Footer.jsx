"use client"
import React from 'react'
import { useDispatch } from 'react-redux'
import { counterDecrement } from '../redux/slice/counterslice'
import Link from 'next/link'



export default function Footer() {

    let dispatch = useDispatch()
    return (
        <>
            <footer>
                
            


                <div className="bg-gray-100 text-gray-700 py-6 px-6 my-10">
                    <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">

                        <div>
                            <button onClick={() => dispatch(counterDecrement())} className="border bg-purple-400 p-2 mx-2">Decrement counter</button>
                            <h2 className="text-lg font-semibold mb-3">Contact Us</h2>
                            <p className="text-sm mb-2">
                                <span className="font-medium">Address:</span> Claritas est etiam processus dynamicus
                            </p>
                            <p className="text-sm mb-2">
                                <span className="font-medium">Phone:</span> 98745612330
                            </p>
                            <p className="text-sm mb-2">
                                <span className="font-medium">Email:</span>
                                <a href="mailto:furnitureinfo@gmail.com" className="text-blue-600 hover:underline">
                                    furnitureinfo@gmail.com
                                </a>
                            </p>


                            <div className="flex space-x-4 mt-3">
                                <a href="#" className="text-gray-600 hover:text-blue-500 text-xl">
                                    <i className="fab fa-facebook"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-pink-500 text-xl">
                                    <i className="fab fa-instagram"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-400 text-xl">
                                    <i className="fab fa-twitter"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-700 text-xl">
                                    <i className="fab fa-linkedin"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-red-600 text-xl">
                                    <i className="fab fa-youtube"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-400 text-xl">
                                    <i className="fab fa-telegram"></i>
                                </a>
                            </div>
                        </div>
                        <div>
                            <h2 className="text-lg font-semibold mb-3">Information</h2>
                            <p className="text-sm mb-2">
                                <span className="font-medium">About Us</span>
                            </p>
                            <p className="text-sm mb-2">
                                <span className="font-medium">Contact Us</span>
                            </p>
                            <p className="text-sm mb-2">
                                <span className="font-medium">Frequently Questions</span>

                            </p>


                            <div className="flex space-x-4 mt-3">
                                <a href="#" className="text-gray-600 hover:text-blue-500 text-xl">
                                    <i className="fab fa-facebook"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-pink-500 text-xl">
                                    <i className="fab fa-instagram"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-400 text-xl">
                                    <i className="fab fa-twitter"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-700 text-xl">
                                    <i className="fab fa-linkedin"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-red-600 text-xl">
                                    <i className="fab fa-youtube"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-400 text-xl">
                                    <i className="fab fa-telegram"></i>
                                </a>
                            </div>
                        </div>
                        <div>
                            <h2 className="text-lg font-semibold mb-3">My Account</h2>
                            <span className="text-sm mb-2">
                                <Link href="/my-dashboard" className="font-medium cursor-pointer hober:text-[#c09578]">My deshboard</Link>
                            </span>
                            <p className="text-sm mb-2">
                                <Link href="/Wishlist-us" className="font-medium cursor-pointer hover:underline hover:text-[#c09578]">Wishlist</Link>
                            </p>
                            <p className="text-sm mb-2">
                        <p className="text-sm mb-2">
  <Link
    href="/Cart-us"
    className="font-medium cursor-pointer hover:underline  hover:text-[#c09578]">Cart</Link></p>

                                {/* <a className="font-medium cursor-pointer" href="#cart-address">Cart</a> */}

                            </p>
                            <p className="text-sm mb-2">
                                <span className="font-medium">Checkout</span>
                            </p>


                            <div className="flex space-x-4 mt-3">
                                <a href="#" className="text-gray-600 hover:text-blue-500 text-xl">
                                    <i className="fab fa-facebook"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-pink-500 text-xl">
                                    <i className="fab fa-instagram"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-400 text-xl">
                                    <i className="fab fa-twitter"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-700 text-xl">
                                    <i className="fab fa-linkedin"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-red-600 text-xl">
                                    <i className="fab fa-youtube"></i>
                                </a>
                                <a href="#" className="text-gray-600 hover:text-blue-400 text-xl">
                                    <i className="fab fa-telegram"></i>
                                </a>
                            </div>
                        </div>
                        <div className=''>
                            <h2 className="text-lg font-semibold mb-3">Top Rated Products</h2>
                            <div className='flex border-b my-4'>
                                <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/products/1615225341228Ganthur%20Sheesham%20Wood%20Sofa%20Set___.jpg" className='h-15 w-20' alt="" />

                                <div className='mx-5'>
                                    <p>2 seater sofa</p>
                                    <h2>Ganthur Sheesham  Wood Sofa Set</h2>
                                    <div className='flex'>
                                        <span className='line-through mr-3 '>Rs. 8,000</span>
                                        <p className='text-yellow-700'>  Rs.7,600</p>
                                    </div>


                                </div>
                            </div>
                            <div className='flex border-b '>
                                <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/products/1608312103476Dorian%20Shoe%20Rack_.jpg" className='h-15 w-20' alt="" />

                                <div className='mx-5'>
                                    <p>Display Unit</p>
                                    <h2>Dorian Shoe Rack</h2>
                                    <div className='flex'>
                                        <span className='line-through mr-3 '>Rs. 3,500</span>
                                        <p className='text-yellow-700'>  Rs.2,600</p>
                                    </div>


                                </div>
                            </div>





                        </div>


                    </div>
                </div>
                <section>
                    <div className='max-w-4xl mx-auto bg-gray-200 '>
                        <div className='grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-1 text-center border-b border-t border-gray-200 my-10 '>
                            <div className='font-bold text-2xl py-5'>Home</div>
                            <div className='font-bold text-2xl py-5'>Online Store</div>
                            <div className='font-bold text-2xl py-5'>Privcy Policy</div>
                            <div className='font-bold text-2xl py-5'>Trems of use</div>
                        </div>
                    </div>
                    <div className='text-center'>
                        <h1 className='text-center'>All Rights Reserved By Furniture | © 2025</h1>
                        <div className='flex justify-center my-3'>

                            <img src="https://wscubetech.co/Assignments/furniture/public/frontend/img/icon/papyel2.png" alt="" />
                        </div>

                    </div>
                </section>
            </footer>

        </>
    )
}
