"use client"
import { CiSearch } from "react-icons/ci";
import { FaArrowDown, FaHeart } from "react-icons/fa";
import { MdShoppingCart } from "react-icons/md";
import { IoIosArrowDown } from "react-icons/io";


import React from 'react'
import Link from "next/link";
import { useDispatch, useSelector } from "react-redux";
import { counterIncrement } from "../redux/slice/counterslice";
import { redirect } from "next/navigation";
import { logoutData } from "../redux/slice/userslice";

export default function Header() {

  let cart =useSelector ((mystore) => mystore.myCart.cart)

  let counter = useSelector((myStore) =>myStore.myCounter.count)
  let loginuser = useSelector((myStore) =>myStore.user.user)
  
  let dispatch = useDispatch();


  let logoutuser=()=>{
    dispatch(logoutData())
    redirect('/Login-us')
  }



  return (
    <header>
      <div className="max-w-[1270px] mx-auto">


        <div className=' flex justify-between py-2 border border-gray-200 mt-3'>
          <div className='mx-5'> Contact us 24/7 : +91-98745612330 / furnitureinfo@gmail.com
            {counter}
            <button  onClick={() => dispatch(counterIncrement())} className="border bg-purple-400 p-2 mx-2">Add counter</button>
          </div>
          <div>
           
              {
                loginuser ?
                <>
                {loginuser.userName}
                <button onClick={logoutuser} type="button" className="border m-2  px-2 py-1 rounded-lg bg-red-500  hover:text-white">Logout</button>
                </>
                :
                 <div className='mx-5'>
                 <Link href="/Login-us"> Login /</Link>
            <Link href="/Register-us"> Register</Link>

              </div>
              }
            {/* <Link href="/Login-us"> Login /</Link>
            <Link href="/Register-us"> Register</Link> */}
            
          </div>
        </div>
        <section>

          <div className="flex  justify-between  border border-gray-200 py-2 ">
            <div className=" mx-5 space-x-16">
              <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/company-profile/logo/cccfbdab-3bec-439f-88b9-5694698cd302-1670132652.png" className="w-50 h-10" alt="" />

            </div>

            <div className="flex">

              <div className=" relative flex  mr-5   py-2">

                <input type="text" placeholder='search product' className="pb-4 border border-gray-200 relative   rounded-lg" />
                <button className="border ">

                  <CiSearch className=" text-4xl py-2 absolute left-[80%]  bottom-[20%] cursor-pointer" />
                </button>


              </div>
              <div className="flex mr-5   py-2">


                <span className=" mx-2 text-2xl  justify-center  "><FaHeart className="border border-gray-200  text-4xl py-1 rounded-lg " /></span>
                <div className="flex mx-2 justify-center  rounded-lg py-2 border border-gray-200">

                  <MdShoppingCart className="text-2xl mx-2  justify-center  text-2xl cursor-pointer " />
                  {cart.length}
                </div>

                <div className="flex mx-2 justify-center  rounded-lg py-2 border border-gray-200">

                  <h1 className=" mx-2 ">| Rs. 0.00</h1> <IoIosArrowDown className="mx-2  text-2xl" />
                </div>
              </div>
            </div>
          </div>
        </section>
        <section>

          <div className="my-4 grid lg:grid-cols " >
            <ul className="flex justify-center  gap-20 font-bold">
              <li>Home</li>
              <li className="relative group cursor-pointer">
                <div className="flex items-center gap-1">
                  <Link href="/" className="hover:text-red-500 transition">LIVING</Link>
                  <IoIosArrowDown className="mt-1" />
                </div>

                {/* Dropdown Start */}
                <div className="absolute left-0 top-full mt-3 bg-white shadow-lg border border-gray-200 rounded-lg w-[650px] 
                  opacity-0 invisible translate-y-2 scale-100
                  group-hover:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:scale-100 
                  transition-all duration-500 ease-in z-50 p-6">
                  <div className="grid grid-cols-3 gap-8">

                    {/* Column 1 */}
                    <div>
                      <h2 className="font-bold text-gray-800 mb-3 uppercase">Tables</h2>
                      <ul className="space-y-2 text-gray-600">
                        <li className="hover:text-red-500"><Link href="/living/side-end-tables">Side And End Tables</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/nest-tables">Nest Of Tables</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/coffee-table-sets">Coffee Table Sets</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/coffee-tables">Coffee Tables</Link></li>
                      </ul>
                    </div>

                    {/* Column 2 */}
                    <div>
                      <h2 className="font-bold text-gray-800 mb-3 uppercase">Living Storage</h2>
                      <ul className="space-y-2 text-gray-600">
                        <li className="hover:text-red-500"><Link href="/living/prayer-units">Prayer Units</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/display-unit">Display Unit</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/shoe-racks">Shoe Racks</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/chest-drawers">Chest Of Drawers</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/cabinets-sideboard">Cabinets & Sideboard</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/bookshelves">Bookshelves</Link></li>
                        <li className="hover:text-red-500"><Link href="/living/tv-units">TV Units</Link></li>
                      </ul>
                    </div>

                    {/* Column 3 */}
                    <div>
                      <h2 className="font-bold text-gray-800 mb-3 uppercase">Mirror</h2>
                      <ul className="space-y-2 text-gray-600">
                        <li className=""><Link href="/living/wooden-mirrors">Wooden Mirrors</Link></li>
                      </ul>
                    </div>
                  </div>
                </div>
                {/* Dropdown End */}
              </li>
              <li className="relative group cursor-pointer">
                <div className="flex items-center gap-1">
                  <Link href="/" className="hover:text-red-500 transition">SOFA</Link>
                  <IoIosArrowDown className="mt-1" />
                </div>

                {/* Dropdown Start */}
                <div className="absolute left-0 top-full mt-3 bg-red-100 shadow-lg border border-gray-200 rounded-lg w-[650px] 
                  opacity-0 invisible translate-y-2 scale-100
                  group-hover:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:scale-100 
                  transition-all duration-500 ease-in z-50 p-6">
                  <div className="grid grid-cols-3 gap-6">

                    {/* Column 1 */}
                    <div>
                      <h2 className="font-bold text-gray-800 mb-3 uppercase">SOFA CUM BED</h2>
                      <ul className="space-y-2 text-gray-600">
                        <li className="hover:text-[#C09578]"><Link href="/living/side-end-tables">wooden sofa cum bed </Link></li>

                      </ul>
                    </div>

                    {/* Column 2 */}
                    <div>
                      <h2 className="font-bold text-gray-800 mb-3 uppercase">SOFA SETES</h2>
                      <ul className="space-y-2 text-gray-600">
                        <li className="hover:text-[#C09578]"><Link href="/living/side-end-tables">LShape Sofa </Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/nest-tables">1 Seater Sofa</Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/coffee-table-sets">2 Seater Sofa</Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/coffee-tables">3 Seater Sofa</Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/coffee-tables">wooden Sofa Sets</Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/coffee-tables">Normal</Link></li>
                      </ul>
                    </div>

                    {/* Column 3 */}
                    <div>
                      <h2 className="font-bold text-gray-800 mb-3 uppercase">SWING JHULA</h2>
                      <ul className="space-y-2 text-gray-600">
                        <li className=""><Link href="/living/wooden-mirrors">Wooden Jhula</Link></li>
                      </ul>
                    </div>
                  </div>
                </div>
                {/* Dropdown End */}
              </li>
              <li className="relative group cursor-pointer">
                <div className="flex items-center gap-1">
                  <Link href="/" className="hover:text-red-500 transition">PAGES</Link>
                  <IoIosArrowDown className="mt-1" />
                </div>

                {/* Dropdown Start */}
                <div className="absolute left-0 top-full mt-3 bg-red-100 shadow-lg border border-gray-200 rounded-lg w-[200px] 
                  opacity-0 invisible translate-y-2 scale-100
                  group-hover:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:scale-100 
                  transition-all duration-500 ease-in z-50 p-6">
                  <div className="text-center">

                    {/* Column 1 */}
                    <div>
                      <ul className="space-y-2 text-gray-600">
                        <li className="hover:text-[#C09578]"><Link href="/living/side-end-tables">About </Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/side-end-tables">Cart</Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/side-end-tables">Checkout </Link></li>
                        <li className="hover:text-[#C09578]"><Link href="/living/side-end-tables">Greqentlyt Questions </Link></li>


                      </ul>
                    </div>

                  </div>
                </div>
                {/* Dropdown End */}
              </li>
              <li>Contact us</li>
            </ul>
          </div>
        </section>
      </div>
    </header>
  )
}
