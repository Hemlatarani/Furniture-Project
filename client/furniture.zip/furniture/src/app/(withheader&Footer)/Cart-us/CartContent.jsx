import React from 'react'

export default function CartContent() {
  return (
    <>
    <section>
        <div className='max-w-[1270px] mx-atuo my-5'>

            <div className='flex justify-center border-t border-gray-200 '>
                <img src="https://wscubetech.co/Assignments/furniture/public/frontend/img/icon/my-Order.jpg" alt="" />
            </div>
            <div>
                <h5 className='text-center border-b border-gray-200 py-4'>Your Shopping Cart is empty!</h5>
            </div>
        </div>
    </section>
    </>
  )
}
