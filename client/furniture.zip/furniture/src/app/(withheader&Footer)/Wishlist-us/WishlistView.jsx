import React from 'react'

export default function wishlistView() {
  return (
    <section>

   <div className='max-w-[2170px] mx-auto my-10 '>
        <div className='flex justify-center border-t border-gray-200 '>
            <img   src="https://wscubetech.co/Assignments/furniture/public/frontend/img/icon/wishlist-Empty.jpg" alt="" />

        </div>
        <div>
            <h5 className='text-center border-b border-gray-200 py-5'>Your Wishlist is Empty!</h5>

        </div>

    </div>
    </section>
  )
}
