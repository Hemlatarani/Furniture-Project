
import { singleProduct } from '@/app/api-service/productservice';
import Breadcrumb from '@/app/common/Breadcrumb';
import React from 'react'
import ProductView from './ProductView';
export const methodName =  {
  title:"AboutPage"
}


export default async function ProductDetails(data) {
let {id} = await data.params;
let productData= await singleProduct(id)
console.log(productData)
  return (
    <div>
      productData &&
      <>
      <Breadcrumb pageName={productData.title}/>
      <ProductView data={productData}/>
      </>
    </div>
  )
}

