"use client"
import React, { useState } from 'react'

export default function ProductView({data}) {
    let [currentImg,setcurrentImg]=useState(data.thumbnail)
let {images}=data
  return (
    <section >
        <div className='max-w-[1270px] mx-auto grid grid-cols-[45%_auto] py-5 gap-10'>
           
            <div>

            <img width={"100%"} src={currentImg} alt="" />
            <div className='flex gap-2 '>
{
    images.map((src,index)=> <img onClick={()=>setcurrentImg(src)} className='border-1' width={"25%"} src={src} alt=''/>)
}
            </div>
            </div>
            {/* <div className='py-5 align-center'>
                <h1 className='font-bold text-2xl'>{data.title}</h1>
                <p className='font-bold text-2xl'>{data.price}</p>
                <p className='font-bold text-2xl'>{data.rating}</p>
            </div> */}
            
        </div>
    </section>
  )
}
