import React from 'react'
import ProductCart from '../common/ProductCart'



export default function Productlist({ product }) {

  return (
    <>
      <div className='grid grid-cols-3 gap-3'>
        {product?.map((data, index) => <ProductCart key={index} data={data} />
        )}


      </div>
    </>

  )
}

