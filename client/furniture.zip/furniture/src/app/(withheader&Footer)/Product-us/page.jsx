// "use client"
// import React, { useEffect, useState } from 'react'
// import Breadcrumb from '../common/Breadcrumb'
// import Productfilter from './Productfilter'
// import Productlist from './Productlist'
// import axios from 'axios'

// export default function Products() {
//     let [product,setproducts]=useState();
    
//     let getproduct=()=>{
//         axios.get("https://dummyjson.com/products")
//         .then((Res)=>Res.data)
//         .then((final)=> setproducts(final.products))
        
//     }

//     useEffect(()=>{
//         getproduct();
//     },[])
  
//     let pageName="Products"
//   return (
//     <>
//     <Breadcrumb  pageName={pageName}/>
//     <div className='max-w-[1270px] mx-auto   grid grid-cols-[20%_auto] gap-10 '>

//     <Productfilter/>
//     <Productlist product={product}/>
//     </div>
//     </>
//   )
// }
"use client";

import React, { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import axios from "axios";
import Breadcrumb from "@/app/common/Breadcrumb";
import Productfilter from "./Productfilter";
import Productlist from "./Productlist";

export default function page() {
  // const params = useParams(); // URL se id milta hai
  // const [product, setProduct] = useState(null);

  // useEffect(() => {
  //   axios.get(`https://dummyjson.com/products/${params.id}`)
  //     .then(res => setProduct(res.data))
  //     .catch(err => console.log(err));
  // }, [params.id]);

  // if (!product) return <div>Loading...</div>;

  return (
    <div>

      <Breadcrumb pageName={pageName}/>
      <div className="max-w-[1320px] mx-auto grid gird-cols-[20%_auto] gap-5 ">
        <Productfilter/>
        <Productlist/>
    </div>


      {/* <img src={product.thumbnail} alt={product.title} className="mb-5" />
      <h1 className="text-2xl font-bold py-2">{product.title}</h1>
      <h2 className="text-lg py-1">Category: {product.category}</h2>
      <p className="py-2">{product.description}</p>
      <p className="font-bold text-xl">Price: ${product.price}</p> */}
    </div>
  );
}
