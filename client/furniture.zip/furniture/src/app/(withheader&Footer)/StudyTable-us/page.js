import React from 'react'
import Breadcrumb from '../common/Breadcrumb'
import TableContent from './TableContent'
import TableProduct from './TableProduct'
import TableUpsells from './TableUpsells'

export default function StudyTable() {
    let pageName="Caronline Study Table"
  return (
    <>
    
    <Breadcrumb pageName={pageName}/>
    <TableContent/>
    <TableProduct/>
    <TableUpsells/>
    
    </>
  )
}
