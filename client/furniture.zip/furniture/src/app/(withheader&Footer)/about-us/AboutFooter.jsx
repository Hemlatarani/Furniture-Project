import React from 'react'

export default function AboutFooter() {
  return (
    <>

   <section>
        <div className='max-w-4xl mx-auto bg-gray-200 '>
            <div className='grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-1 text-center border-b border-t border-gray-200 my-10 '>
    <div className='font-bold text-2xl py-5'>Home</div>
    <div className='font-bold text-2xl py-5'>Online Store</div>
    <div className='font-bold text-2xl py-5'>Privcy Policy</div>
    <div className='font-bold text-2xl py-5'>Trems of use</div>
            </div>
        </div>
    <div className='text-center'>
            <h1 className='text-center'>All Rights Reserved By Furniture | © 2025</h1>
            <div className='flex justify-center my-3'>

            <img  src="https://wscubetech.co/Assignments/furniture/public/frontend/img/icon/papyel2.png"  alt=""  />
            </div>

        </div>
    </section>
        </>
  )
}
