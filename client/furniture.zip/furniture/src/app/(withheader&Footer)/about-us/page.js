import React from 'react'
import Breadcrumb from '../common/Breadcrumb'
import Aboutcontent from './Aboutcontent'
import AboutChoose from './AboutChoose'
import Aboutlast from './Aboutlast'
import AboutCustomer from './AboutCoustumer'
import AboutFooter from './AboutFooter'
export const metadata={
title:"About-Us",
description:"About page description"
}
export default function AboutUs() {
  let pageName="About Us"
  metadata
  return (
    <div>
      <Breadcrumb pageName={pageName}/>
  <Aboutcontent/>
  <AboutChoose/>
  <AboutCustomer/>
  <Aboutlast/>
  <AboutFooter/>
    </div>
  )
}
