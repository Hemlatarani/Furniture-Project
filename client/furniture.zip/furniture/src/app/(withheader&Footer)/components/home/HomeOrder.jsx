
"use client"
import React from 'react'
import { IoMdTime } from "react-icons/io";
import { GiWorld } from "react-icons/gi";
import { IoMdCheckmarkCircleOutline } from "react-icons/io";




export default function HomeOrder() {
  return (
    <>
     <section>
      <div className='max-w-6xl mx-auto'>
        <div className='grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 justify-items-center'>
          <div className='border-1 h-50 w-50'></div>
          <div className='border-1 h-50 w-50'></div>
          <div className='border-1 h-50 w-50'></div>

        </div>
      </div>
            </section>
    </>
  )
}
