import React from 'react'
import { IoIosArrowBack } from "react-icons/io";
import { IoIosArrowForward } from "react-icons/io";
import { CiHeart } from "react-icons/ci";






export default function HomeSeles() {
    return (
        <>
            <section>

                <div className="w-full flex justify-center    mt-[50px]">
                    {/* Heading */}
                    <h2 className="text-3xl font-bold text-gray-600">BestSelling Products</h2>

                    {/* Center Line */}
                    <div className="w-150 h-[3px] bg-gray-300 mt-2 rounded-full mt-5 ml-2"></div>
                    <div className='flex mt-2 '><IoIosArrowBack className='font-bold text-2xl text-gray-300' /><IoIosArrowForward className='font-bold text-2xl text-gray-300' />

                    </div>
                </div>

            </section>
            <section>

                <div className='max-w-[1270px] mx-auto border-t border-b border-gray-300 mt-2'>
                    <div className='grid lg:grid-cols-5  sm:grid-cols-2 md:grid-cols-1 mx-15 my-15 gap-4'>
                        <div className='h-[100%] w-[100%] shadow-2xl'>
                            <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/products/16253167208651620078433247Louise%20Cabinet_.jpg" alt="" />

                            <h2 className='text-center py-2 text-gray-400'>Cabinets and Sideboard</h2>
                            <p className='font-bold  text-center  py-3 border-b border-gray-400'>Louise Cabinets</p>
                            <div>
                                <div className='flex justify-center gap-5 py-3'>

                                    <p className='line-through'>Rs.28,000  </p>
                                    <span className='text-[#c09578]'>Rs. 23000</span>
                                </div>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <div className=''>

                                    <CiHeart className='border  text-3xl my-2 py-1 text-red-600 border-1 border- ' />
                                </div>
                                <button className='border  border-black-400 bg-gray-3000 bg-gray-300 p-[3px_10] my-2'>Add To Cart</button>
                            </div>
                        </div>
                        <div className='h-90 w-[100%] shadow-2xl'>
                            <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/products/1620077669499Erica%20Bookshelfs_brown.jpg" alt="" />

                            <h2 className='text-center py-2 text-gray-400'>Bookshelves</h2>
                            <p className='font-bold  text-center  py-3 border-b border-gray-400'>Erica Bookshelfs</p>
                            <div>
                                <div className='flex justify-center gap-5 py-3'>

                                    <p className='line-through'>Rs.38,000  </p>
                                    <span className='text-[#c09578]'>Rs. 3,0000</span>
                                </div>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <div className=''>

                                    <CiHeart className='border   text-3xl my-2 py-1 text-red-600 border-1 border- ' />
                                </div>
                                <button className='border  border-black-400 bg-gray-3000 bg-gray-300 p-[3px_10] my-2'>Add To Cart</button>
                            </div>
                        </div>
                        <div className='h-90 w-[100%] shadow-2xl'>
                            <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/products/1617981904164Hrithvik%20Stool__.jpg" alt="" />

                            <h2 className='text-center py-2 text-gray-400'>Side and Table</h2>
                            <p className='font-bold  text-center  py-3 border-b border-gray-400'>Hrihivik Stool</p>
                            <div>
                                <div className='flex justify-center gap-5 py-3'>

                                    <p className='line-through'>Rs.7000  </p>
                                    <span className='text-[#c09578]'>Rs. 6000</span>
                                </div>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <div className=''>

                                    <CiHeart className='border  text-3xl my-2 py-1 text-red-600 border-1 border- ' />
                                </div>
                                <button className='border   border-black-400 bg-gray-400 bg-gray-300 p-[3px_10] my-2'>Add To Cart</button>
                            </div>
                        </div>
                        <div className='h-90 w-[100%] shadow-2xl'>
                            <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/products/1617829052195Caroline%20Study%20Tables__.jpg" alt="" />

                            <h2 className='text-center py-2 text-gray-400'>Nest Of Tables</h2>
                            <p className='font-bold  text-center py-3 border-b border-gray-400'>CarOline Study Tables</p>
                            <div>
                                <div className='flex justify-center gap-5 py-3'>

                                    <p className='line-through'>Rs.3000  </p>
                                    <span className='text-[#c09578]'>Rs. 2,500</span>
                                </div>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <div className=''>

                                    <CiHeart className='border  text-3xl my-2 py-1 text-red-600 border-1 border- ' />
                                </div>
                                <button className='border border-black-400 bg-gray-300 p-[3px_10] my-2'>Add To Cart</button>
                            </div>
                        </div>
                        <div className='h-90 w-[100%] shadow-2xl'>
                            <img src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/products/1617828302132Godfrey%20Coffee%20Table%20Set__.jpg" alt="" />

                            <h2 className='text-center py-2 text-gray-400'>Coffee Tables Sets</h2>
                            <p className='font-bold  text-center  py-3 border-b border-gray-400'>Godfrey Coffee Table Set</p>
                            <div>
                                <div className='flex justify-center gap-5 py-3'>

                                    <p className='line-through'>Rs.3000  </p>
                                    <span className='text-[#c09578]'>Rs. 2,200</span>
                                </div>
                            </div>
                            <div className='flex justify-center gap-2'>
                                <div className=''>

                                    <CiHeart className='border  text-3xl my-2 py-1 text-red-600 border-1 border- ' />
                                </div>
                                <button className='border  border-black-400 bg-gray-300 p-[3px_10] my-2'>Add To Cart</button>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
        </>
    )
}
