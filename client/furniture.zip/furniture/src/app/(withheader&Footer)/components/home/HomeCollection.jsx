import React from 'react'

export default function HomeCollection() {
  return (
    <section className='  border-b border-gray-200 py-5'>
      <div className='max-w-[1270px] mx-auto'>

      <div className='grid lg:grid-cols-3  md:grid-cols-1 pt-5 gap-5 mx-5'>
<div className='group-hover overflow-hidden duration-200 relative '>
  
<img className='hover:scale-125 cursor-pointer' src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/home-page/124ad5ba-005d-4b47-a707-a9a87033833a-1670180400.webp" alt=""
height={500}
width={500}/>
<div className='absolute bottom-35 left-5'>
<h5>Design Creative</h5> 
<h1 className='font-bold text-2xl'>Chair Collection</h1>
</div>
</div>
<div className='group-hover overflow-hidden duration-200 relative '>
  
<img className='hover:scale-125 cursor-pointer' src=" https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/home-page/0d588bec-d9a0-4645-8e7a-b49ef67b34be-1670180400.webp" alt="" />
<div className='absolute bottom-35 left-5'>
<h5>BestSelling Product</h5>
<h1 className='font-bold text-2xl'>Chair Collection</h1>
</div>
</div>
<div className='group-hover overflow-hidden duration-200 relative '>
  
<img className='hover:scale-125 cursor-pointer' src="https://wscubetech.co/Assignments/furniture/storage/app/public/uploads/images/home-page/124ad5ba-005d-4b47-a707-a9a87033833a-1670180400.webp" alt="" />
<div className='absolute bottom-35 left-5'>
<h5>Onsale Product</h5>
<h1 className='font-bold text-2xl'>Chair Collection</h1>
</div>
</div>




      </div>
      </div>
    </section>
  )
}
