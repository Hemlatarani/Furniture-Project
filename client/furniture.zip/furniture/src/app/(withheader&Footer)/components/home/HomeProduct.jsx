"use client"
import { homeFeaturedProduct } from '@/app/api-service/homeservice'
import ProductCart from '@/app/common/ProductCart'



import React, { useState } from 'react'

export default function HomeProduct({productData}) {
  let [product,setproduct]=useState(productData)

  const handleCatgory= async(category)=>{
    let data=await homeFeaturedProduct(category);
    setproduct(data);

  }
  
  
  return (
    <div className='m-[20px_40px]'>
      <div className='flex justify-center gap-10'>
        <button 
        onClick={()=>handleCatgory("furniture")}
        className='bg-premium-500 text-2xl border px-3 py-2 text-[#c09578] gap-2 hover:bg-[#c09578] hover:text-white'>Featured</button>
        <button 
        onClick={()=>handleCatgory("laptops")}
        className='bg-premium-500 text-2xl border px-3 py-2 text-[#c09578] gap-2 hover:bg-[#c09578] hover:text-white'>New Arrivels</button>
        <button 
        onClick={()=>handleCatgory("smartphones")}
        className='bg-premium-500 text-2xl border px-3 py-2 text-[#c09578] gap-2 hover:bg-[#c09578] hover:text-white'>Onsale</button>
  </div>
  <div className='max-w-[1320px] mx-auto grid grid-cols-4 my-3'>
 {
 product.map((data,index) => (

   <ProductCart key={index} data={data} />
  )
)}

  </div>
    </div>
  )
}
