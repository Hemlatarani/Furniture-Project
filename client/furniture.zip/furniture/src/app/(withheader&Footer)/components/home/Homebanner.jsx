"use client"
import React from 'react'
import Slider from "react-slick"

export default function Homebanner({bannerdata}) {
    var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };

  return (
  
    <section className='overflow-hidden  '>
    <Slider {...settings}>
      {bannerdata.map((item,index)=>{
 return(
 <div  >
        <img src={item.thumbnail}  alt="" />
        <p>{item.ranting}</p>
      </div>
 )
      })}
     
     
      
    </Slider>

    </section>
  
  )
}
