import { configureStore }from"@reduxjs/toolkit";
import  counterReducer  from "../slice/counterslice";
import  cartReducer  from "../slice/cartslice";
import  userReducer from "../slice/userslice";






export const store=configureStore( {
reducer:{
    myCounter:counterReducer,
    myCart:cartReducer,
    user:userReducer
}
}
)