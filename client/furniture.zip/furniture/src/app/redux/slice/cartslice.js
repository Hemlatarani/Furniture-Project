const { createSlice } = require("@reduxjs/toolkit");



export  let cartSlice=createSlice({
    name :"cart",
    initialState:{
        cart:[],
    },
    reducers:{
        addTocart:(state,reqData)=>{
            let {payload}=reqData
            state.cart.push(payload)
        },
        DeleteCart:(state,reqData)=>{
            let {payload}=reqData
                let id= payload.id
                state.cart=state.cart.filter((item)=>item.id!==id)
        }
    }
})
export default cartSlice.reducer;
export const {addTocart,DeleteCart}=cartSlice.actions