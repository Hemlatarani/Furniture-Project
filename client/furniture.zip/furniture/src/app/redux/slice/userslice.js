const { createSlice } = require("@reduxjs/toolkit");
import  Cookies from "js-cookie";


export let userSlice=createSlice(
    {
        name:"user",
        initialState:{
            user:Cookies.get("user") ? JSON.parse(Cookies.get("user")) : null
        },
         reducers:{
       getuserData:function(state,reqData){
            let {payload}=reqData
            state.user=(payload)
            Cookies.set("user",JSON.stringify(state.user))
        },
        logoutData:function(state){
        state.user=null
        Cookies.remove("user")
               
        }
    }
}
)
export default userSlice.reducer;
export const {getuserData,logoutData}=userSlice.actions