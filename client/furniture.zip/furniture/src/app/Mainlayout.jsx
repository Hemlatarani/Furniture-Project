"use client"
import React from 'react'

import { store } from './redux/store/store'
import { Provider } from 'react-redux'


export default function Mainlayout({children}) {
  return (

    <Provider store={store}>
      {children}
    </Provider>
  
  )
}
