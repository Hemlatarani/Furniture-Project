import React from 'react'
import ThankYou from './Thankyoupage'

export default function page() {
  return (
    <div>
      <ThankYou/>
    </div>
  )
}
