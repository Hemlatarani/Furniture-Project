// import { NextResponse } from 'next/server'

 
// export function middleware(request) {
//   if (! request.cookies.get('USER')) {
//     return NextResponse.redirect(new URL('/login', request.url));
//   }
//   else{
//      if (request.nextUrl.pathname.startsWith('/login')) {
//     return NextResponse.rewrite(new URL('/my-dashboard', request.url))
//    }
//   }
//   return NextResponse.next();
//  }
//  export const config={
//     matcher:["/my-dashboard",'/contact-us','/wishlist']
//  }
import { NextResponse } from "next/server";

export function middleware(request) {
  const res = NextResponse.next();

  // ✅ REQUIRED for Firebase Google popup
  res.headers.set(
    "Cross-Origin-Opener-Policy",
    "same-origin-allow-popups"
  );

  const user = request.cookies.get("USER");

  // 🔐 Protected routes
  if (!user && request.nextUrl.pathname !== "/login") {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  // 🔁 Prevent logged-in user from seeing login page
  if (user && request.nextUrl.pathname === "/login") {
    return NextResponse.redirect(new URL("/my-dashboard", request.url));
  }

  return res;
}

export const config = {
  matcher: ["/login", "/my-dashboard", "/contact-us", "/wishlist"],
};